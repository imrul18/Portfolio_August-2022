<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PostTable extends Model
{
    use HasFactory;

    protected $fillable = [
        'post',
        'type',
        'url',
    ];

}
